package com.myjavablog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDatabaseSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDatabaseSecurityApplication.class, args);
	}

}



